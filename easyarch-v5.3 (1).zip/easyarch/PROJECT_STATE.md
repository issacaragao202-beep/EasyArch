# PROJECT_STATE — EasyArch v5.3 (Instalação ISO 1 Comando + Pós-Instalação 1 Clique)

> **Versão única do repositório:** `EasyArch v5.3` · **Data:** 2026-11-20
> **Hardware-alvo:** AMD Ryzen 5 3400G (4C/8T · Zen+) · Radeon Vega 11 · 8 GB DDR4 single-channel 2667 MHz (~6 GB utilizáveis) · Mancer B450M-DA V2SC · SSD SATA Kingston A400 240 GB · Monitor 1920×1080 @ 75 Hz · UEFI.

---

## 1. Pacote Atual
- **Arquivo:** `easyarch-v5.3.zip` (repositório limpo e unificado sob `easyarch/`).
- **Relatórios de Auditoria e Evolução:** `docs/08-auditoria-e-correcoes-estruturais-v4.1.md` até `docs/20-instalacao-facil-v5.3.md`.

## 2. Estado Real das Validações (Sem Resultados Fictícios)
- **Sintaxe Bash (`bash -n`) e permissões `0755`:** Aprovadas em todos os 42 scripts `.sh` (41 em `scripts/` + `tests/run-tests.sh`).
- **Suíte `tests/run-tests.sh`:** 222 verificações automatizadas (incluindo `easyarch-instalar-iso.sh`, `easyarch-setup.sh --auto`, `easyarch-aplicar-etc.sh --yes` e integração na ISO).
- **Pendentes em ambiente real (Arch Linux VM UEFI e hardware Ryzen 5 3400G):** `mkarchiso`, execução real do `easyarch-instalar`, `nft -c`, `cpupower frequency-info`, boot UEFI + AppArmor + Hyprland + Waydroid.
